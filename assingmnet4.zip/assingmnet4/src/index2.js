const express = require('express')
const http = require('http');
const app = express()
const port = process.env.PORT ||3000
app.use(express.json());
const socketio = require('socket.io');
const server = http.createServer(app);
var bodyParser = require('body-parser');
app.use(bodyParser.json());
const io = socketio(server)
const { employee, salary, expertise, project, leave, leave_details } = require('../models/employeeDb_model');


//employee-data-saving
io.on('connection', (socket)=>{
    console.log('Connection with socket');
    socket.on('save_data',async (data, callback)=>{
        try {
            const newEmployee = await new employee(data)
            const newSalary = await new salary(req.body)
            const newProject = await new project(req.body)
            const newExpertise = await new expertise(req.body)
            const newLeave = await new leave(req.body)
            const newLeave_details = await new leave_details(req.body)
          
            await newEmployee.save();
            newSalary.emp_id = newEmployee.emp_id;
            await newSalary.save();
            newProject.emp_id = newEmployee.emp_id;
            await newProject.save();
            newExpertise.emp_id = newEmployee.emp_id;
            await newExpertise.save();
            newLeave.emp_id = newEmployee.emp_id;
            await newLeave.save();
            newLeave_details.leave_id = newLeave.leave_id;
            await newLeave_details.save();
            
            res.json({ employee: newEmployee,
            Salary:newSalary,
            Project:newProject,
            Expertise:newExpertise,
            Leave:newLeave,
            Leave_Details:newLeave_details
            }) 
        } catch(error) {
            console.error(error)
        }
        callback();

    })
    
})
////////////////// Get of Employee by id  /////////////////////////////////
app.get('/employee/:emp_id',async (req, res)=>{
    try{ 
    let employee1 = await employee.findOne({
        where:{
            emp_id:req.params.emp_id
        },
         include:[
             {
                 as:'employee_salary_relation',
                 model:salary,
             },
             {
                 as:'employee_project_relation',
                 model:project,
             },
             {
                 as:'employee_expertise_relation',
                 model:expertise,
             }
             ,
             {
                 as:'employee_leave_relation',
                 model:leave,
                 include:[{
                    as:'leave_leave_details_relation',
                    model:leave_details
                    
                 } 
                 ],
             }
             
         ]
     }
     )
    employee1 = JSON.parse(JSON.stringify(employee1));
    let employee_data = {
                name: employee1.name,
                age: employee1.age,
                gender: employee1.gender,
                salary: employee1.salary,
                dob: employee1.dob,
                doj: employee1.doj,
                dol: employee1.dol,
                resume: employee1.resume,
                bonus: employee1.bonus
                    }
    const salary_data = employee1.employee_salary_relation;
    const project_data = employee1.employee_project_relation;
    const expertise_data = employee1.employee_expertise_relation;
    const leave_data = employee1.employee_leave_relation;
    const leave_data1 = {
        med_leaves_avail:leave_data.med_leaves_avail,
        annual_leaves_avail:leave_data.annual_leaves_avail,
        med_leave_availed:leave_data.annual_leave_availed,
        annual_leave_availed:leave_data.annual_leave_availed

    } 
    const leave_details_data = leave_data.leave_leave_details_relation;
    let EMPLOYEE1 = { ...employee_data, ...salary_data, ...project_data, ...expertise_data , ...leave_data1 ,...leave_details_data} 
   
    res.json({EMPLOYEE:EMPLOYEE1})
    }catch(error){
        res.json({Error:"Error"})
    }
 })
 
 /////////////////////////////Update data of an employee////////////////////////
app.patch('/employee/:emp_id', async(req, res)=>{
    const emp_Id = req.params.emp_id;
    const changedValues = req.body;
    try{
        const result1 = await employee.update(
            changedValues
        ,{
                where:{
                    emp_id:emp_Id
                }
            }
        )
        const result2 = await salary.update(
            changedValues
        ,{
                where:{
                    emp_id:emp_Id
                }
            }
        )
        const result3 = await expertise.update(
            changedValues
        ,{
                where:{
                    emp_id:emp_Id
                }
            }
        )
        const result4 = await project.update(
            changedValues
        ,{
                where:{
                    emp_id:emp_Id
                }
            }
        )
        const result5 = await leave.update(
            changedValues
        ,{
                where:{
                    emp_id:emp_Id
                }
            }
        )
        let leave1 = await leave.findAll({
            where: {
            emp_id: emp_Id
            }
            }
            )
        leave1 = JSON.parse(JSON.stringify(leave1));
        const leave_Id = leave1[0].leave_id
        const result6 = await leave_details.update(
            changedValues
        ,{
                where:{
                    leave_id:leave_Id
                }
            }
        )
        if(result1[0] || result2[0] || result3[0] || result4[0] || result5[0] || result6[0]){
            return res.json({ Employee:changedValues });
         }
         res.json({Error:"ID not exist"});
         
    }
    catch(error){
        console.log(error);
    }

})


//////////////////////////////////////////Get Monthly Salary/////////////////////////////////
app.get('/employee/salary/:emp_id',async(req, res)=>{
    const emp_Id = req.params.emp_id;
    try{
        const employee1 = await employee.findAll({
            where:{
                emp_id:emp_Id
            }
        })
        if(!employee1[0]){
            return res.json({Error:"ID does'nt Exist"});
            }
        const salary1 = await salary.findAll({
            where:{
                emp_id:emp_Id
            }
        })
        
        let salary_data = JSON.parse(JSON.stringify(salary1));
        let employee_data = JSON.parse(JSON.stringify(employee1));
        employee_data = employee_data[0];
        salary_data = salary_data[0];
        let monthly_hours_worked = 24*8;
        let hourly_rate = employee_data.salary/monthly_hours_worked;
        let over_time_salary = salary_data.overtime*hourly_rate;
        let total_salary = employee_data.salary + salary_data.medical_reimbursement + salary_data.other_reimbursement + over_time_salary ;
        res.json({Total_salary:total_salary}); 
        }
        catch(error)
        {
            console.log(error);
        }
    })


///////////////////////////////////////////////////////////////////////////////////

////////////////// Data Pagination  /////////////////////////////////
app.get('/employee',async (req, res)=>{
   await employee.findAll({
       limit:req.query.limit,
       offset:req.query.offset,
        include:[
            {
                as:'employee_salary_relation',
                model:salary,
            },
            {
                as:'employee_project_relation',
                model:project,
            },
            {
                as:'employee_expertise_relation',
                model:expertise,
            },
            {
                as:'employee_leave_relation',
                model:leave,
                include:[{
                   as:'leave_leave_details_relation',
                   model:leave_details,
                   
                } 
                ],
            }
            
        ]
    }
    ).then(data=>{
        res.json({Employee_DATA:data})
    }).catch(error=>{
        console.log(error);
    })
   
})


server.listen(port, () => console.log(`Example app listening on port ${port}!`))



// employee.belongsTo(salary, {foreignKey:'emp_id',constraints:false, as:'employee_salary_relation'});
// expertise.belongsTo(employee, {
//     foreignKey: 'emp_id',
//     constraints: true,
//     as: 'employee'
//   });
// employee.belongsTo(expertise, {foreignKey:'emp_id',constraints:false, as:'employee_expertise_relation'});
// project.belongsTo(employee, {
//     foreignKey: 'emp_id',
//     constraints: true,
//     as: 'employee'
//   });

// employee.belongsTo(project, {foreignKey:'emp_id',constraints:false, as:'employee_project_relation'});  

// leave.belongsTo(employee, {
//     foreignKey: 'emp_id',
//     constraints: true,
//     as: 'employee'
//   });

// employee.belongsTo(leave, {foreignKey:'emp_id',constraints:false, as:'employee_leave_relation'});  

// leave.hasMany(leave_details, {
//     foreignKey: 'leave_id',
//     constraints: true,
//     as:'leave_details'
//   });  

// leave.belongsTo(leave_details, {foreignKey:'leave_id',constraints:false, as:'leave_leave_details_relation'});  
  