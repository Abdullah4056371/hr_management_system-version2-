fetch('http://localhost:3000/employee' , {credentials: "include"}).then(res=>res.json()).then(data=>console.log(data));

// const Http = new XMLHttpRequest();
// const url='http://172.31.208.1:3000/employee';
// Http.open("GET", url);
// Http.send();

// Http.onreadystatechange = (e) => {
//   console.log(Http.responseText)
// }

console.log("Javascript")
var data;

let form ;
let name_inp ;
let age_inp ;
let gender_inp ;
let salary_inp ;
let dob_inp ;
let doj_inp ;
let dol_inp ;
let resume_inp ;
let bonus_inp ;
let exp_name_inp ;
let exp_detail_inp ;
let med_leave_available_inp ;
let annual_leave_available_inp ;
let med_leave_availed_inp ;
let annual_leave_availed_inp ;
let med_leave_availed_on_inp ;
let annual_leave_availed_on_inp ;
let project_name_inp ;
let project_detail_inp ;
let overtime_inp ;
let medical_reimbursement_inp ;
let other_reimbursement_inp ;

let body1;

async function employee_function()
{
  name_inp =  document.getElementById("name_inp").value;
  age_inp =  document.getElementById("age_inp").value;
  gender_inp =  document.getElementById("gender_inp").value;
  salary_inp =  document.getElementById("salary_inp").value;
  dob_inp =  document.getElementById("dob_inp").value;
  doj_inp =  document.getElementById("doj_inp").value;
  dol_inp =  document.getElementById("dol_inp").value;
  resume_inp =  document.getElementById("resume_inp").value;
  bonus_inp =  document.getElementById("bonus_inp").value;
  exp_name_inp =  document.getElementById("exp_name_inp").value;
  exp_detail_inp =  document.getElementById("exp_detail_inp").value;
  med_leave_available_inp =  document.getElementById("med_leave_available_inp").value;
  annual_leave_available_inp =  document.getElementById("annual_leave_available_inp").value;
  med_leave_availed_inp =  document.getElementById("med_leave_availed_inp").value;
  annual_leave_availed_inp =  document.getElementById("annual_leave_availed_inp").value;
  med_leave_availed_on_inp =  document.getElementById("med_leave_availed_on_inp").value;
  annual_leave_availed_on_inp =  document.getElementById("annual_leave_availed_on_inp").value;
  project_name_inp =  document.getElementById("project_name_inp").value;
  project_detail_inp =  document.getElementById("project_detail_inp").value;
  overtime_inp =  document.getElementById("overtime_inp").value;
  medical_reimbursement_inp =  document.getElementById("medical_reimbursement_inp").value;
  other_reimbursement_inp =  document.getElementById("other_reimbursement_inp").value;
  console.log(name_inp);

   body1 = {
    "name":name_inp,
    "age":age_inp,
    "gender":gender_inp,
    "dob":dob_inp,
    "doj":doj_inp,
    "dol":dol_inp,
    "resume":resume_inp,
    "bonus":bonus_inp,
    "salary":salary_inp,
    "overtime":overtime_inp,
    "medical_reimbursement":medical_reimbursement_inp,
    "other_reimbursement":other_reimbursement_inp,
    "expertise_name":exp_name_inp,
    "expertise_detail":exp_detail_inp,
    "project_name":project_name_inp,
    "project_detail":project_detail_inp,
    "med_leaves_avail":med_leave_available_inp,
    "annual_leaves_avail":annual_leave_available_inp,
    "med_leave_availed":med_leave_availed_inp,
    "annual_leave_availed":annual_leave_availed_inp,
    "med_leave_availed_on":med_leave_availed_on_inp,
    "annual_leave_availed_on":annual_leave_availed_on_inp

}

// res.setHeader("Access-Control-Allow-Origin", "*");
// res.setHeader("Access-Control-Allow-Credentials", "true");
// res.setHeader("Access-Control-Max-Age", "1800");
// res.setHeader("Access-Control-Allow-Headers", "content-type");
// res.setHeader("Access-Control-Allow-Methods","PUT, POST, GET, DELETE, PATCH, OPTIONS");
// res.setHeader("Content-Type", "application/json;charset=utf-8");

 let body2 = JSON.stringify(body1);
console.log(body2);
await fetch('http://172.31.208.1:3000/employee', { mode:'cors' ,method: 'POST', headers: {
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Credentials":"true",
  "Access-Control-Max-Age":"1800",
  "Access-Control-Allow-Headers":"content-type",
  "Access-Control-Allow-Methods":"PUT, POST, GET, DELETE, PATCH, OPTIONS",
  "Content-Type":"application/json;charset=utf-8"


},  body:body2  } ).then(response => response.json())
.then(result => {
  console.log('Success:', result);
})
.catch(error => {
  console.error('Error:', error);
});
}
// }
//   let result = await response.json();
//   alert(result.message);
// }

// try{
// let response = fetch('http://localhost:3000/employee');
// response.then(result =>{
//   console.log(result);
// })
// }
// catch(error)
// {
//   console.log(error);
// }
 
function createTable()
{
  // fetch('http://localhost:3000/employee', {
  //   method:'GET',
  //   mode:'no-cors'
  // })
  // .then(result => {result.json()})
  // .then(data => console.log(data));
  let rn = 2; 
  let cn = 22; 
  const entries = Object.entries(body1);
  const keys = Object.keys(body1);
  const values = Object.values(body1)
  //body1 = JSON.parse(body1);
 for(var r=0;r<parseInt(rn,10);r++)
  {
    var checkbox = document.createElement('input');
    checkbox.type = "checkbox";
    checkbox.value = "value";
    checkbox.id = r+"c"; 
    var x= document.getElementById('myTable').insertRow(r);
    document.getElementById('myTable').x
    x.id = r+"r";
   for(var c=0;c<parseInt(cn,10);c++)  
    {
       if(r===0)
       {
         var y=  x.insertCell(c);
         y.innerHTML= keys[c]; 
       }
       if(r!==0){
        var y=  x.insertCell(c);
        y.innerHTML= values[c];
     

       } 
    }
   }
}

function delete_records()
{
  for(let i=0; i<2 ; i++){
  var ch_box = document.getElementById(i+"c")
  var row_element =document.getElementById(i+'r')
  console.log(ch_box)
  console.log(row_element)
  if(ch_box.checked){
  ch_box.parentNode.removeChild(ch_box);
  row_element.parentNode.removeChild(row_element);
  }
  }
}